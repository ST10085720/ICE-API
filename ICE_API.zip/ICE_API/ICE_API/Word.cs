﻿using System.Security.Cryptography;

namespace prjWordApi
{
    public class Word
    {
        String[] arrWords = new string[10];
        private static Word instance;
        public Word() 
        {
            arrWords[0] = "shell";
            arrWords[1] = "acceptable";
            arrWords[2] = "siege";
            arrWords[3] = "fair";
            arrWords[4] = "reflection";
            arrWords[5] = "bottle";
            arrWords[6] = "shadow";
            arrWords[7] = "tiger";
            arrWords[8] = "pill";
            arrWords[9] = "permission";

        }   
        public static getInstance()
        {
            if(instance == null)
            {
                instance = new Word();
              
            }
            return instance;
        }
       public String[] All()
        {
            return arrWords;
        }
        public String[] Sorted()
        {
            return arrWords.OrderBy(x => x).ToArray();
        }
      public String Single()
        {
            Random rnd = new Random();
            return arrWords[rnd.Next(arrWords.Length)];     

        }

    }
}
