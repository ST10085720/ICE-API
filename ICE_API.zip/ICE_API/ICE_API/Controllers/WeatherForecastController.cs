using Microsoft.AspNetCore.Mvc;
using prjWordApi;

namespace ICE_API.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class WeatherForecastController : ControllerBase
    {
        private static readonly string[] Summaries = new[]
        {
        "Freezing", "Bracing", "Chilly", "Cool", "Mild", "Warm", "Balmy", "Hot", "Sweltering", "Scorching"
    };

        private readonly ILogger<WeatherForecastController> _logger;

        public WeatherForecastController(ILogger<WeatherForecastController> logger)
        {
            _logger = logger;
        }

        [HttpGet("GetSingle")]//instance
        public string Getsingle()
        {
            Word w= new Word();
            return w.Single();
        }
        [HttpGet("GetAll")]
        public String[] GetAll()
        {
            Word w = new Word();
            return w.All();
        }
        [HttpGet("GetSorted")]
        public String[] Getsorted()
        {
            Word w = new Word();
            return w.Sorted();
        }
    }

}

    
